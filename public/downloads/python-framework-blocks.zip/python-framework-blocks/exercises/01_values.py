available = 10  # 调整前库存
amount = None  # TODO：填写调整量；None 暂时表示未填写  # 本次减少 2
result = available + amount  # 算出调整后的库存
print(result)  # 把结果显示出来
