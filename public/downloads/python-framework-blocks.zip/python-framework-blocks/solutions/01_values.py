available = 10  # 调整前库存
amount = -3  # 本次减少 3
result = available + amount  # 算出调整后的库存
print(result)  # 把结果显示出来
